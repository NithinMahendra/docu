import os
from document_reader import run_tesseract
from local_llm import run_local_llm

def extract_details(image_path):
    text = run_tesseract(image_path)
    print("🧾 OCR Text:\n", text[:500])  # Print first 500 chars
    structured_output = run_local_llm(text)
    return structured_output

if __name__ == "__main__":
    input_folder = "sample_docs"
    output_folder = "outputs"
    os.makedirs(output_folder, exist_ok=True)

    for file_name in os.listdir(input_folder):
        if file_name.lower().endswith((".jpg", ".jpeg", ".png", ".pdf")):
            path = os.path.join(input_folder, file_name)
            print(f"\n📄 Processing: {file_name}")
            result = extract_details(path)
            
            out_path = os.path.join(output_folder, f"{file_name}.json")
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(result)
            print(f"✅ Saved to {out_path}")
