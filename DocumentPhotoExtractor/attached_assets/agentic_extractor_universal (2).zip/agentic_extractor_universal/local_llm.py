import requests

def run_local_llm(doc_text):
    prompt = f"""
Extract the following personal details from the text below and return in JSON format:
- Full Name
- Date of Birth
- Gender
- Nationality
- Category (e.g., SC/ST/OBC/General)
- Contact Details (Phone, Email)
- Address
- Document Type (like Aadhaar, SSC, Income, etc.)
- Any ID Numbers (e.g., Aadhaar number, Certificate No.)

Text:
\"\"\"
{doc_text}
\"\"\"
"""

    headers = {
        "Authorization": "Bearer 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",
        "Content-Type": "application/json"
    }

    payload = {
        "model": "openchat/openchat-3.5-0106",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that extracts structured personal data from any Indian document."},
            {"role": "user", "content": prompt}
        ]
    }

    response = requests.post("https://openrouter.ai/api/v1/chat/completions", json=payload, headers=headers)

    if response.status_code == 200:
        return response.json()["choices"][0]["message"]["content"]
    else:
        return f"Error: {response.status_code} - {response.text}"
