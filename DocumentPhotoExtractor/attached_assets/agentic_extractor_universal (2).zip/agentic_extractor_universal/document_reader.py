from PIL import Image
import pytesseract

def run_tesseract(image_path):
    image = Image.open(image_path).convert("RGB")
    text = pytesseract.image_to_string(image, lang='eng')
    return text
